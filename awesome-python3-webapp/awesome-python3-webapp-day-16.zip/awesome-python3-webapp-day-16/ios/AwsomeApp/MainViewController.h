//
//  MainViewController.h
//  LearnGit
//
//  Created by Michael Liao on 4/22/14.
//  Copyright (c) 2014 iTranswarp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "APBlog.h"

@interface MainViewController : UIViewController

- (void)initBlog:(APBlog*) blog;

@end
